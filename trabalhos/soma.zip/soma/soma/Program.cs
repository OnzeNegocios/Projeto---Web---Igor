﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace soma
{
    class Program
    {
        static void Main(string[] args)
        {
            int vValor1=0, vValor2=0, vResultado=0;

            // Entrada de dados

            Console.WriteLine("Digite o valor 1: ");
            vValor1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor 2: ");
            vValor2 = int.Parse(Console.ReadLine());

            // Proecessamento 

            vResultado = vValor1 + vValor2;

            // Saída da informação

            Console.WriteLine("Resultado= "+ vResultado);

            Console.ReadKey();
        }
    }
}
