﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enquanto
{
    class Program
    {
        static void Main(string[] args)
        {
            double vCont = 1, vNum = 0, vNum2 =0;

            while (vCont <= 5) {
            
                Console.WriteLine("Digite o numero");
                vNum = Convert.ToDouble(Console.ReadLine());
                vNum2 = vNum + vNum2;

                vCont = vCont + 1;


            }

            Console.WriteLine("Numero" + vNum2);

           
            }
        
        }
    }
