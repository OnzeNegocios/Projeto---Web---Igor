﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int vPar = 0, vCont = 0;

            Console.WriteLine("Digite o numero");
            vPar = Convert.ToInt16(Console.ReadLine());

            for (vPar = 0; vPar <= vCont; vPar = vCont + 2) {
                Console.WriteLine(vCont);
            }
        }
    }
}
